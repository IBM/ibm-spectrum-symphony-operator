#!/bin/bash

echo Hello from $0

